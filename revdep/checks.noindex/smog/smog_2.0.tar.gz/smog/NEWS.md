# smog 1.0 

**smog 1.0** is the *first* release that contains the work on constrained structural modeling by using overlapped group penalties since June, 2018.

This release aims to fit a generalized linear model for the cases of small n, large p data, conditioning on the expertise knowledge by non-penalizing some phenotype covariate variables, and penalizing the groups of prognostic and predictive effects by using overlapped L2 and L1 penalties.    

